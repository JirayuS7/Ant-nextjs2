"use strict";
exports.id = 706;
exports.ids = [706];
exports.modules = {

/***/ 7706:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ teams)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
;// CONCATENATED MODULE: ./teams.json
const teams_namespaceObject = JSON.parse('{"Walter White":{"name":"Walter White","position":"Chief Executive Officer","descripiton":"Explicabo voluptatem mollitia et repellat qui dolorum quasi","photo":"img/team/team-1.jpg","linken":"https://www.linkedin.com/"},"Sarah Jhonson":{"name":"Sarah Jhonson","position":"Product Manager","descripiton":"Aut maiores voluptates amet et quis praesentium qui senda para","photo":"img/team/team-2.jpg","linken":"https://www.linkedin.com/"},"William Anderson":{"name":"Mark Ruffalo","position":"Accountant","descripiton":"Aut maiores voluptates amet et quis praesentium qui senda para","photo":"img/team/avatar.png","linken":"https://www.linkedin.com/"},"Mark Wahlberg":{"name":"Mark Wahlberg","position":"Developer","descripiton":"Aut maiores voluptates amet et quis praesentium qui senda para","photo":"img/team/avatar.png","linken":"https://www.linkedin.com/"},"Margot Robbie ":{"name":"Margot Robbie ","position":"Marketing","descripiton":"Aut maiores voluptates amet et quis praesentium qui senda para","photo":"img/team/avatar.png","linken":"https://www.linkedin.com/"},"Elizabeth Olsen ":{"name":"Elizabeth Olsen  ","position":"Graphic Design","descripiton":"Aut maiores voluptates amet et quis praesentium qui senda para","photo":"img/team/avatar.png","linken":"https://www.linkedin.com/"},"Robert Downey Jr":{"name":"Robert Downey Jr","position":"Photo & Video","descripiton":"Aut maiores voluptates amet et quis praesentium qui senda para","photo":"img/team/avatar.png","linken":"https://www.linkedin.com/"}}');
;// CONCATENATED MODULE: ./pages/component/teams.js



const Teams = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ jsx_runtime_.jsx("section", {
            id: "team",
            className: "team section-bg",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "container",
                "data-aos": "fade-up",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "section-title",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                children: "Team"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "\u0E1A\u0E38\u0E04\u0E25\u0E32\u0E01\u0E23\u0E43\u0E19\u0E1A\u0E23\u0E34\u0E29\u0E31\u0E17 \u0E41\u0E2D\u0E19\u0E17\u0E4C\u0E04\u0E2D\u0E21\u0E40\u0E21\u0E34\u0E23\u0E4C\u0E0B \u0E21\u0E35\u0E40\u0E14\u0E35\u0E22 \u0E08\u0E4D\u0E32\u0E01\u0E31\u0E14 \u0E40\u0E1B\u0E47\u0E19\u0E1A\u0E38\u0E04\u0E25\u0E32\u0E01\u0E23\u0E40\u0E08\u0E19\u0E40\u0E19\u0E2D\u0E40\u0E23\u0E0A\u0E31\u0E48\u0E19\u0E43\u0E2B\u0E21\u0E48\u0E17\u0E35\u0E48\u0E21\u0E35\u0E27\u0E34\u0E2A\u0E31\u0E22\u0E17\u0E31\u0E28\u0E19\u0E4C\u0E40\u0E14\u0E35\u0E22\u0E27\u0E01\u0E31\u0E19\u0E17\u0E35\u0E48\u0E15\u0E49\u0E2D\u0E07\u0E01\u0E32\u0E23\u0E21\u0E38\u0E48\u0E07\u0E40\u0E19\u0E49\u0E19\u0E1E\u0E31\u0E12\u0E19\u0E32\u0E17\u0E34\u0E28\u0E17\u0E32\u0E07\u0E02\u0E2D\u0E07\u0E01\u0E32\u0E23\u0E15\u0E25\u0E32\u0E14\u0E14\u0E49\u0E32\u0E19\u0E2D\u0E35\u0E04\u0E2D\u0E21\u0E40\u0E21\u0E34\u0E23\u0E4C\u0E0B \u0E43\u0E2B\u0E49\u0E2A\u0E2D\u0E14\u0E04\u0E25\u0E49\u0E2D\u0E07\u0E01\u0E31\u0E1A\u0E04\u0E27\u0E32\u0E21\u0E15\u0E49\u0E2D\u0E07\u0E01\u0E32\u0E23\u0E02\u0E2D\u0E07\u0E18\u0E38\u0E23\u0E01\u0E34\u0E08 \u0E40\u0E28\u0E23\u0E29\u0E10\u0E01\u0E34\u0E08\u0E43\u0E19\u0E22\u0E38\u0E04\u0E1B\u0E31\u0E08\u0E08\u0E38\u0E1A\u0E31\u0E19\u0E41\u0E25\u0E30\u0E2D\u0E19\u0E32\u0E04\u0E15 \u0E0B\u0E36\u0E48\u0E07\u0E21\u0E35\u0E04\u0E27\u0E32\u0E21\u0E0A\u0E4D\u0E32\u0E19\u0E32\u0E0D\u0E43\u0E19\u0E2A\u0E32\u0E22\u0E07\u0E32\u0E19\u0E14\u0E49\u0E32\u0E19\u0E15\u0E48\u0E32\u0E07\u0E46 \u0E17\u0E31\u0E49\u0E07\u0E14\u0E49\u0E32\u0E19\u0E01\u0E32\u0E23\u0E08\u0E31\u0E14\u0E17\u0E4D\u0E32\u0E2A\u0E37\u0E48\u0E2D\u0E2D\u0E2D\u0E19\u0E44\u0E25\u0E19\u0E4C,\u0E01\u0E32\u0E23\u0E27\u0E34\u0E40\u0E04\u0E23\u0E32\u0E30\u0E2B\u0E4C\u0E01\u0E32\u0E23\u0E15\u0E25\u0E32\u0E14, \u0E40\u0E28\u0E23\u0E29\u0E10\u0E01\u0E34\u0E08, \u0E01\u0E32\u0E23\u0E27\u0E32\u0E07\u0E41\u0E1C\u0E19\u0E23\u0E39\u0E1B\u0E41\u0E1A\u0E1A\u0E07\u0E32\u0E19\u0E17\u0E31\u0E49\u0E07\u0E17\u0E32\u0E07\u0E23\u0E30\u0E22\u0E30\u0E2A\u0E31\u0E49\u0E19\u0E41\u0E25\u0E30\u0E23\u0E30\u0E22\u0E30\u0E22\u0E32\u0E27\u0E43\u0E2B\u0E49\u0E01\u0E25\u0E38\u0E48\u0E21\u0E25\u0E39\u0E01\u0E04\u0E49\u0E32\u0E41\u0E25\u0E30\u0E01\u0E25\u0E38\u0E48\u0E21\u0E04\u0E39\u0E48\u0E04\u0E49\u0E32\u0E43\u0E2B\u0E49\u0E44\u0E14\u0E49\u0E23\u0E31\u0E1A\u0E1B\u0E23\u0E30\u0E42\u0E22\u0E0A\u0E19\u0E4C\u0E2A\u0E39\u0E07\u0E2A\u0E38\u0E14"
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "row",
                        children: Object.entries(teams_namespaceObject).map((value, index)=>{
                            return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
                                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "col-lg-6 mb-3",
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "member d-flex align-items-start",
                                        "data-aos": "zoom-in",
                                        "data-aos-delay": "100",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "pic",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                    src: value[1].photo,
                                                    className: "img-fluid",
                                                    alt: value[1].name
                                                })
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "member-info",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                                        children: value[1].name
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                        children: value[1].position
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                        children: value[1].descripiton
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                        className: "social",
                                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                                            href: value[1].linken,
                                                            children: [
                                                                " ",
                                                                /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                                    className: "ri-linkedin-box-fill"
                                                                }),
                                                                " "
                                                            ]
                                                        })
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                })
                            });
                        })
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const teams = (Teams);


/***/ })

};
;