"use strict";
exports.id = 103;
exports.ids = [103];
exports.modules = {

/***/ 9103:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ portfolio)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
;// CONCATENATED MODULE: ./ports.json
const ports_namespaceObject = JSON.parse('{"p1":{"title":"Port title 1","content":"hey this is my first post","image":"img/portfolio/B-accounting-imac-website-design.jpg","link":"#","category":"filter-app"},"p2":{"title":"Port title 2","content":"hey this is my first post","image":"img/portfolio/B-accounting-mobile-website-design-iphone_.jpg","link":"#","category":"filter-design"},"p3":{"title":"Port title 3","content":"hey this is my first post","image":"img/portfolio/Base-Solar-Computer-Website-Design.jpg","link":"#","category":"filter-app"},"p4":{"title":"Port title 4","content":"hey this is my first post","image":"img/portfolio/Base-Solar-MacBook-Website-Design.jpg","link":"#","category":"filter-design"},"p5":{"title":"Port title 5","content":"hey this is my first post","image":"img/portfolio/Base-Solar-Website-Iphone-Black.jpg","link":"#","category":"filter-app"},"p6":{"title":"Port title 6","content":"hey this is my first post","image":"img/portfolio/Intega-websitesite-design-tablet.jpg","link":"#","category":"filter-app"},"p7":{"title":"Port title 7","content":"hey this is my first post","image":"img/portfolio/iphone.jpg","link":"#","category":"filter-app"},"p8":{"title":"Port title 8","content":"hey this is my first post","image":"img/portfolio/Lub-D-website-design-computer.jpg","link":"#","category":"filter-web"},"p9":{"title":"Port title 9","content":"hey this is my first post","image":"img/portfolio/Lub-D-website-design-mobile.jpg","link":"#","category":"filter-app"},"p10":{"title":"Port title 10","content":"hey this is my first post","image":"img/portfolio/Mirhi-laptop-website-design-macbook.jpg","link":"#","category":"filter-web"},"p11":{"title":"Port title 11","content":"hey this is my first post","image":"img/portfolio/Mirihi-website-design-ipad.jpg","link":"#","category":"filter-app"},"p12":{"title":"Port title 12","content":"hey this is my first post","image":"img/portfolio/MPG-website-design-macbook.jpg","link":"#","category":"filter-web"},"p13":{"title":"Port title 13","content":"hey this is my first post","image":"img/portfolio/PIA-Interior-website-design-iphone.jpg","link":"#","category":"filter-app"},"p14":{"title":"Port title 14","content":"hey this is my first post","image":"img/portfolio/PIA-Interior-website-design-tablette.jpg","link":"#","category":"filter-app"},"p15":{"title":"Port title 15","content":"hey this is my first post","image":"img/portfolio/portfolio-1.jpg","link":"#","category":"filter-design"},"p16":{"title":"Port title 16","content":"hey this is my first post","image":"img/portfolio/portfolio-2.jpg","link":"#","category":"filter-design"},"p17":{"title":"Port title 17","content":"hey this is my first post","image":"img/portfolio/portfolio-3.jpg","link":"#","category":"filter-design"},"p18":{"title":"Port title 18","content":"hey this is my first post","image":"img/portfolio/portfolio-4.jpg","link":"#","category":"filter-design"},"p19":{"title":"Port title 19","content":"hey this is my first post","image":"img/portfolio/portfolio-5.jpg","link":"#","category":"filter-card"},"p20":{"title":"Port title 20","content":"hey this is my first post","image":"img/portfolio/portfolio-6.jpg","link":"#","category":"filter-card"},"p21":{"title":"Port title 21","content":"hey this is my first post","image":"img/portfolio/portfolio-7.jpg","link":"#","category":"filter-card"},"p22":{"title":"Port title 21","content":"hey this is my first post","image":"img/portfolio/portfolio-8.jpg","link":"#","category":"filter-card"},"p23":{"title":"Port title 21","content":"hey this is my first post","image":"img/portfolio/portfolio-9.jpg","link":"#","category":"filter-card"},"p24":{"title":"Port title 24","content":"hey this is my first post","image":"img/portfolio/portfolio-details-1.jpg","link":"#","category":"filter-card"},"p25":{"title":"Port title 25","content":"hey this is my first post","image":"img/portfolio/portfolio-details-2.jpg","link":"#","category":"filter-card"},"p26":{"title":"Port title 26","content":"hey this is my first post","image":"img/portfolio/portfolio-details-3.jpg","link":"#","category":"filter-card"},"p27":{"title":"Port title 27","content":"hey this is my first post","image":"img/portfolio/SJ-website-design-iphone.jpg","link":"#","category":"filter-app"},"p28":{"title":"Port title 28","content":"hey this is my first post","image":"img/portfolio/SJ-website-design-macbook.jpg","link":"#","category":"filter-web"}}');
;// CONCATENATED MODULE: ./pages/component/portfolio.js


const Portfolios = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ jsx_runtime_.jsx("section", {
            id: "portfolio",
            className: "portfolio",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "container",
                "data-aos": "fade-up",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "section-title",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                children: "Portfolio"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "\u0E40\u0E1B\u0E47\u0E19\u0E40\u0E27\u0E25\u0E32\u0E01\u0E27\u0E48\u0E32 10 \u0E1B\u0E35\u0E41\u0E25\u0E49\u0E27\u0E17\u0E35\u0E48\u0E40\u0E23\u0E32\u0E44\u0E14\u0E49\u0E0A\u0E48\u0E27\u0E22\u0E25\u0E39\u0E01\u0E04\u0E49\u0E32\u0E43\u0E19  \u0E1B\u0E23\u0E30\u0E40\u0E17\u0E28\u0E44\u0E17\u0E22 \u0E41\u0E25\u0E30\u0E17\u0E31\u0E48\u0E27\u0E42\u0E25\u0E01\u0E43\u0E2B\u0E49\u0E41\u0E1A\u0E23\u0E19\u0E14\u0E4C\u0E02\u0E2D\u0E07\u0E1E\u0E27\u0E01\u0E40\u0E02\u0E32\u0E21\u0E35\u0E40\u0E2D\u0E01\u0E25\u0E31\u0E01\u0E29\u0E13\u0E4C\u0E41\u0E25\u0E30\u0E40\u0E2A\u0E23\u0E34\u0E21\u0E1E\u0E25\u0E31\u0E07\u0E43\u0E19\u0E01\u0E32\u0E23\u0E22\u0E01\u0E40\u0E04\u0E23\u0E37\u0E48\u0E2D\u0E07\u0E40\u0E1E\u0E37\u0E48\u0E2D\u0E40\u0E1B\u0E25\u0E35\u0E48\u0E22\u0E19\u0E43\u0E2B\u0E49\u0E40\u0E1B\u0E47\u0E19\u0E18\u0E38\u0E23\u0E01\u0E34\u0E08\u0E17\u0E35\u0E48\u0E40\u0E1B\u0E25\u0E35\u0E48\u0E22\u0E19\u0E40\u0E01\u0E21\u0E44\u0E14\u0E49 \u0E40\u0E1B\u0E47\u0E19\u0E40\u0E27\u0E25\u0E32\u0E01\u0E27\u0E48\u0E32 10 \u0E1B\u0E35\u0E41\u0E25\u0E49\u0E27\u0E17\u0E35\u0E48\u0E40\u0E23\u0E32\u0E44\u0E14\u0E49\u0E0A\u0E48\u0E27\u0E22\u0E25\u0E39\u0E01\u0E04\u0E49\u0E32\u0E43\u0E19\u0E01\u0E23\u0E38\u0E07\u0E40\u0E17\u0E1E\u0E2F \u0E1B\u0E23\u0E30\u0E40\u0E17\u0E28\u0E44\u0E17\u0E22 \u0E41\u0E25\u0E30\u0E17\u0E31\u0E48\u0E27\u0E42\u0E25\u0E01\u0E43\u0E2B\u0E49\u0E41\u0E1A\u0E23\u0E19\u0E14\u0E4C\u0E02\u0E2D\u0E07\u0E1E\u0E27\u0E01\u0E40\u0E02\u0E32\u0E21\u0E35\u0E40\u0E2D\u0E01\u0E25\u0E31\u0E01\u0E29\u0E13\u0E4C\u0E41\u0E25\u0E30\u0E40\u0E2A\u0E23\u0E34\u0E21\u0E1E\u0E25\u0E31\u0E07\u0E43\u0E19\u0E01\u0E32\u0E23\u0E22\u0E01\u0E40\u0E04\u0E23\u0E37\u0E48\u0E2D\u0E07\u0E40\u0E1E\u0E37\u0E48\u0E2D\u0E40\u0E1B\u0E25\u0E35\u0E48\u0E22\u0E19\u0E43\u0E2B\u0E49\u0E40\u0E1B\u0E47\u0E19\u0E18\u0E38\u0E23\u0E01\u0E34\u0E08\u0E17\u0E35\u0E48\u0E40\u0E1B\u0E25\u0E35\u0E48\u0E22\u0E19\u0E40\u0E01\u0E21\u0E44\u0E14\u0E49"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                        id: "portfolio-flters",
                        className: "d-flex justify-content-center",
                        "data-aos": "fade-up",
                        "data-aos-delay": "100",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                "data-filter": "*",
                                className: "filter-active",
                                children: "All"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                "data-filter": "#filter-app",
                                children: "Brand Identity"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                "data-filter": "#filter-card",
                                children: "E-shipping"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                "data-filter": "#filter-design",
                                children: "Graphic Design"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                "data-filter": "#filter-web",
                                children: "Web Design"
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "row portfolio-container",
                        "data-aos": "fade-up",
                        "data-aos-delay": "200",
                        children: Object.entries(ports_namespaceObject).map((value, index)=>{
                            return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "col-lg-4 col-md-6 portfolio-item ",
                                    id: value[1].category,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "portfolio-img",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                src: value[1].image,
                                                className: "img-fluid",
                                                alt: ""
                                            })
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "portfolio-info",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                                    children: value[1].title
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                    children: value[1].content
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                    href: value[1].link,
                                                    "data-gallery": "portfolioGallery",
                                                    className: "portfolio-lightbox preview-link",
                                                    title: "App 1",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "bx bx-plus"
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                    href: value[1].link,
                                                    className: "details-link",
                                                    title: "More Details",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "bx bx-link"
                                                    })
                                                })
                                            ]
                                        })
                                    ]
                                })
                            });
                        })
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const portfolio = (Portfolios);


/***/ })

};
;