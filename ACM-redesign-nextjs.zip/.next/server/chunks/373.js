"use strict";
exports.id = 373;
exports.ids = [373];
exports.modules = {

/***/ 5373:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ slide)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
;// CONCATENATED MODULE: ./public/img/hero-img.png
/* harmony default export */ const hero_img = ({"src":"/_next/static/media/hero-img.a5d03eba.png","height":646,"width":780,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAHCAYAAAA1WQxeAAAA3UlEQVR42mP4//8dIwMM3HpvnHvmgc+up399wPwFFxgZLj7/Kfz4zL6wF+tneE28/rU3YdW9txsP33h0485ze7CiOQefii3eeuHM8XN3Xm7be/JZwfxT/6dvufV/xd6LTv///2dk2HP1te+6s6//bzz74FHv0t3/2/qn/e/tWvx/47U3h468+O3I8ODFe+9dh8+dalx0+M28g1fO7750696OUxeOzzn6/P+Wc89nga35//8/c9OUbaX1czdNuvn/v/WN///tZ245Vtk9e4M+w/w1WxkZkMD/7/85kPkA9LJ+baSzusMAAAAASUVORK5CYII="});
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./pages/component/slide.js



const Slides = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("section", {
                id: "hero",
                className: "d-flex align-items-center",
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "container",
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "row",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "col-lg-6 d-flex flex-column justify-content-center pt-4 pt-lg-0 order-2 order-lg-1",
                                "data-aos": "fade-up",
                                "data-aos-delay": "200",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                        children: "Ant Commerce Media"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                        children: "\u0E14\u0E4D\u0E32\u0E40\u0E19\u0E34\u0E19\u0E01\u0E34\u0E08\u0E01\u0E32\u0E23\u0E14\u0E49\u0E32\u0E19\u0E07\u0E32\u0E19\u0E2D\u0E35\u0E04\u0E2D\u0E21\u0E40\u0E21\u0E34\u0E23\u0E4C\u0E0B\u0E41\u0E25\u0E30\u0E2A\u0E37\u0E48\u0E2D\u0E42\u0E06\u0E29\u0E13\u0E32 \u0E1B\u0E23\u0E30\u0E0A\u0E32\u0E2A\u0E31\u0E21\u0E1E\u0E31\u0E19\u0E18\u0E4C\u0E40\u0E1B\u0E47\u0E19\u0E2B\u0E25\u0E31\u0E01 \u0E2D\u0E32\u0E17\u0E34 \u0E01\u0E32\u0E23\u0E2A\u0E23\u0E49\u0E32\u0E07\u0E2A\u0E37\u0E48\u0E2D\u0E18\u0E38\u0E23\u0E01\u0E34\u0E08\u0E2D\u0E2D\u0E19\u0E44\u0E25\u0E19\u0E4C \u0E40\u0E0A\u0E48\u0E19 \u0E2D\u0E2D\u0E01\u0E41\u0E1A\u0E1A\u0E41\u0E25\u0E30\u0E1E\u0E31\u0E12\u0E19\u0E32\u0E40\u0E27\u0E47\u0E1A\u0E44\u0E0B\u0E15\u0E4C\u0E41\u0E25\u0E30\u0E41\u0E2D\u0E1B\u0E1E\u0E25\u0E34\u0E40\u0E04\u0E0A\u0E31\u0E48\u0E19, \u0E01\u0E32\u0E23\u0E17\u0E33\u0E2A\u0E37\u0E48\u0E2D\u0E14\u0E34\u0E08\u0E34\u0E15\u0E2D\u0E25\u0E21\u0E32\u0E40\u0E01\u0E15\u0E15\u0E34\u0E49\u0E07"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "d-flex justify-content-center justify-content-lg-start",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                href: "#portfolio",
                                                className: "btn-get-started scrollto",
                                                children: "View Portfolio"
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                                className: " btn-watch-video",
                                                "data-bs-toggle": "modal",
                                                "data-bs-target": "#exampleModal",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "bi bi-play-circle"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                        children: "\u0E14\u0E39\u0E27\u0E34\u0E14\u0E35\u0E42\u0E2D"
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "col-lg-6 order-1 order-lg-2 hero-img",
                                "data-aos": "zoom-in",
                                "data-aos-delay": "200",
                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    src: "/../public/img/hero-img.png",
                                    width: 780,
                                    height: 646,
                                    className: "img-fluid animated",
                                    alt: ""
                                })
                            })
                        ]
                    })
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "modal fade",
                id: "exampleModal",
                "aria-labelledby": "exampleModalLabel",
                "aria-hidden": "true",
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "modal-dialog modal-lg modal-dialog-centered",
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "modal-content",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "modal-header",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                                        className: "modal-title",
                                        id: "exampleModalLabel",
                                        children: "Ant Commerce Media"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                        type: "button",
                                        className: "btn-close",
                                        "data-bs-dismiss": "modal",
                                        "aria-label": "Close"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "modal-body",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("video", {
                                    style: {
                                        maxWidth: "100%",
                                        width: "100%",
                                        height: "400px"
                                    },
                                    className: "elementor-video",
                                    src: "https://acm.co.th/wp-content/uploads/2022/02/vtr-ant-2022-final.mp4",
                                    controls: true
                                })
                            })
                        ]
                    })
                })
            })
        ]
    });
};
/* harmony default export */ const slide = (Slides);


/***/ })

};
;