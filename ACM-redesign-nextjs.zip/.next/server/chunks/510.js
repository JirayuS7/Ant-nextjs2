"use strict";
exports.id = 510;
exports.ids = [510];
exports.modules = {

/***/ 2510:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ component_Clients)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
;// CONCATENATED MODULE: ./clients.json
const clients_namespaceObject = JSON.parse('{"Company 1":{"url":"https://google.com","image":"/img/clients/client-1.png","name":"Company 1"},"Company 2":{"url":"https://google.com","image":"img/clients/client-2.png","name":"Company 2"},"Company 3":{"url":"https://google.com","image":"img/clients/client-3.png","name":"  Company 3"},"Company 4":{"url":"https://google.com","image":"img/clients/client-4.png","name":"  Company 4"},"Company 5":{"url":"https://google.com","image":"img/clients/client-5.png","name":"  Company 5"},"Company 6":{"url":"https://google.com","image":"img/clients/client-6.png","name":"  Company 6"}}');
// EXTERNAL MODULE: external "react-dom"
var external_react_dom_ = __webpack_require__(6405);
// EXTERNAL MODULE: ./node_modules/next/dist/client/link.js
var client_link = __webpack_require__(1551);
var link_default = /*#__PURE__*/__webpack_require__.n(client_link);
;// CONCATENATED MODULE: ./pages/component/Clients.js




const Clients = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ jsx_runtime_.jsx("section", {
            id: "cliens",
            className: "cliens ",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "container",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "section-title",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                children: "Our Clients"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "\u0E40\u0E2D\u0E40\u0E08\u0E19\u0E0B\u0E35\u0E48\u0E2D\u0E2D\u0E01\u0E41\u0E1A\u0E1A\u0E43\u0E19\u0E40\u0E0A\u0E35\u0E22\u0E07\u0E23\u0E32\u0E22 \u0E02\u0E2D\u0E07\u0E40\u0E23\u0E32\u0E20\u0E32\u0E04\u0E20\u0E39\u0E21\u0E34\u0E43\u0E08\u0E2D\u0E22\u0E48\u0E32\u0E07\u0E40\u0E2B\u0E25\u0E37\u0E2D\u0E40\u0E0A\u0E37\u0E48\u0E2D\u0E01\u0E31\u0E1A\u0E1A\u0E23\u0E34\u0E29\u0E31\u0E17\u0E17\u0E35\u0E48\u0E21\u0E2D\u0E1A\u0E04\u0E27\u0E32\u0E21\u0E44\u0E27\u0E49\u0E27\u0E32\u0E07\u0E43\u0E08\u0E43\u0E2B\u0E49\u0E40\u0E23\u0E32 \u0E01\u0E31\u0E1A\u0E41\u0E1A\u0E23\u0E19\u0E14\u0E4C\u0E17\u0E35\u0E48\u0E21\u0E35\u0E04\u0E48\u0E32\u0E02\u0E2D\u0E07\u0E1E\u0E27\u0E01\u0E40\u0E02\u0E32"
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "row",
                        "data-aos": "zoom-in",
                        children: Object.entries(clients_namespaceObject).map((value, index)=>{
                            return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
                                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "col-lg-2 col-md-4 col-6 d-flex align-items-center justify-content-center",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                        href: value[1].url,
                                        target: "_blank",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                            src: value[1].image,
                                            className: "img-fluid",
                                            alt: ""
                                        })
                                    })
                                }, index)
                            });
                        })
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const component_Clients = (Clients);


/***/ })

};
;